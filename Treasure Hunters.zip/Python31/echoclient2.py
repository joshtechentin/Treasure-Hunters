import sys, socket

#def main():
#port = int(input("What is the port? "))
#Client
#IPAddr = input("What is the IP address of the server? ")
port = 80
IPAddr = "35.40.132.34" #Caitlin's IP
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverSocket.connect((IPAddr, port))
while True:
    message = input("Enter a message: ")
    if message != "quit":
        serverSocket.send(message.encode())
        message = serverSocket.recv(1024).decode()
        print(message)
    else:
        serverSocket.send(message.encode())
        message = serverSocket.recv(1024).decode()
        print("\nGoodbye!")
        break
