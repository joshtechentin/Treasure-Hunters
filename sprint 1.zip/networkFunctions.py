# ALL functions relating to the server/client MUST be created here!

import socket

def fCreatePort():
    testPort = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    testPort.bind(('localhost', 0))
    addr, port = testPort.getsockname()
    testPort.close()
    return port

def fCreateServer(port):
    # creates server connection to client and returns it
    IPAddr = socket.gethostbyname(socket.getfqdn())
    print("Your IP is: " + IPAddr)
    #^^^For Sprint 2: Make this print to the screen
    lclSserverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    lclServerSocket.bind((IPAddr, port))
    lclServerSocket.listen(1)
    lclConnection, lclClientAddress = clientSocket.accept()

    #
    while True:
    message = lclConnection.recv(1024).decode()
    if message != "quit":
        print(message)
        message = "message received."
        lclConnection.send(message.encode())
    else:
        print(message)
        lclConnection.send(message.encode())
        lclServerSocket.close()
        print("\nGoodbye!")
        break
    #return lclConnection

#def fReceiveFromClient():
    # Will add for sprint 2
    # receives key inputs from client

#def fSendToClient():
    # Will add for sprint 2
    # sends key inputs to client

def fCreateClient(IP, port):
    # creates client connection to server and return the socket connecting them
    port = int(input("What is the port? "))
    IPAddr = input("What is the IP address of the server? ")
    #^^^Both to be properly implemented for sprint 2
    lclClientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    lclClientSocket.connect((IPAddr, port))

    #
    while True:
    message = input("Enter a message: ")
    if message != "quit":
        lclClientSocket.send(message.encode())
        message = lclClientSocket.recv(1024).decode()
        print(message)
    else:
        lclClientSocket.send(message.encode())
        message = lclClientSocket.recv(1024).decode()
        lclClientSocket.close()
        print("\nGoodbye!")
        break
    #return lclClientSocket

#def fReceiveFromServer():
    # Will add for sprint 2
    # receives key inputs from server

#def fSendToServer():
    # Will add for sprint 2
    # sends key inputs to server
